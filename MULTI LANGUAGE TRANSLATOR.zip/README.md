---
title: MultiLanguageTranslator
emoji: 🏢
colorFrom: green
colorTo: yellow
sdk: gradio
sdk_version: 4.31.1
app_file: app.py
pinned: false
license: apache-2.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
